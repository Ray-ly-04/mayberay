# Main Replit
+ [ItzzzNemo07](https://replit.com/@ItzzzNemo07)
+ this is backup account of [ItzzzNemo07](https://replit.com/@ItzzzNemo07)






# Nemo Nuker v2
## **Welcome to Nemo Nuker `v2`**
* This Nuker is Updated Version of [**v1**](https://replit.com/@ItzzzNemo07/NUKER-V1).
* Prune Members with selected role 
* This Nuker is for Educational Purposes Only.
* **type `pip install -r requirements.txt` in shell**
## Key
```bash
secret#1337
```
## How to use
```bash
- Install requirements.txt
- Open settings.json
- Fill it
- Run main.py
```
## Creater
* [secret#1337](https://discord.com/users/981583519312666635)

## Support
* [Discord](https://discord.gg/hJr3RfAKzt)
* [Youtube](https://www.youtube.com/@nemorunz)
* [Instagram](https://instagram.com/ig_nemo.14)
- ***If server link gets invalid then dm [me](https://discord.com/users/661364730228768788)***